abstract class BusinessServiceInterface {
  Future<dynamic> getBusinessList();
}