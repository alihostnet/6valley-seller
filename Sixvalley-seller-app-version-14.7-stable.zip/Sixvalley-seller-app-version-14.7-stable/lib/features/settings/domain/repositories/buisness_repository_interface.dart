import 'package:sixvalley_vendor_app/interface/repository_interface.dart';

abstract class BusinessRepositoryInterface implements RepositoryInterface{}