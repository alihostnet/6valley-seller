
abstract class BarcodeServiceInterface {
  Future<dynamic> barCodeDownLoad(int? id, int quantity);
}