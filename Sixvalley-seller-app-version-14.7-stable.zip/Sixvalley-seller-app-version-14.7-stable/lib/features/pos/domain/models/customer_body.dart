class CustomerBody {
  String? fName;
  String? lName;
  String? phone;
  String? email;
  String? country;
  String? city;
  String? zipCode;
  String? address;
  CustomerBody(
      {this.fName,
      this.lName,
      this.phone,
      this.email,
      this.country,
      this.city,
      this.zipCode,
      this.address});
}
